Instalar as dependências

### `npm install`

Rodar o projeto

### `npm start`

Instalar o módulo para manipular rotas

### `npm install --save react-router-dom`
