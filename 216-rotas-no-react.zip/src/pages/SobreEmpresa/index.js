import React from 'react';

function SobreEmpresa(){
    return(
        <h1>Sobre Empresa</h1>
    );
}

export default SobreEmpresa;