import React from 'react';

function Main(){
    return(
        <h1>Página Inicial</h1>
    );
}

export default Main;